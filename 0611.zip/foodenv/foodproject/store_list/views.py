from __future__ import unicode_literals
from django.shortcuts import render,render_to_response
# Create your views here.
from .models import Store_list
from django.shortcuts import redirect


import json

def store_showpost(request,name):
	try:
		post = Store_list.objects.get(name = name)

		if post != None:
			return render(request,'post.html',locals())
	except:
		return redirect('/')

def store_list(request):
	stores = Store_list.objects.all()

	return render(request,'store_list.html',locals())

def search(request):
	stores = Store_list.objects.all()
	List = []
	for i in stores:
		List1=[]
		List1.append(i.name)
		string=""
		if(i.vegetable):
			string +="1"
		else:
			string +="0"
		
		if(i.Halal):
			string +="1"
		else:
			string +="0"
		
		if(i.is_chinese):
			string +="1"
		else:
			string +="0"
		if(i.is_western):
			string +="1"
		else:
			string +="0"
		if(i.is_japan):
			string +="1"
		else:
			string +="0"
		if(i.is_korean):
			string +="1"
		else:
			string +="0"
		if(i.is_expensive):
			string +="1"
		else:
			string +="0"

		List1.append(string)
		List1.append(str(i.stars))
		
		List.append(List1)

	#return render_to_response('store_list/list.html',locals())	
	return render(request,'search.html',locals(), {'List':json.dumps(List)})



