from __future__ import unicode_literals

from django.contrib import admin
from .models import About_us


class About_usAdmin(admin.ModelAdmin):
	list_display = ('origin','origin_img','history','history_img','concept','concept_img')

admin.site.register(About_us)