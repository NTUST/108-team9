from django.shortcuts import render,render_to_response
from .models import About_us


def about_us(request):
	about_us = About_us.objects.all()
	return render(request,'about_us.html',locals())