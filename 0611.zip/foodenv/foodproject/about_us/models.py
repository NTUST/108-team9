# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class About_us(models.Model):
    origin = models.CharField(null=True,max_length=2000)
    origin_img =  models.ImageField(null=True, blank=False)

    history = models.CharField(null=True,max_length=2000)
    history_img =  models.ImageField(null=True, blank=False)

    concept = models.CharField(null=True,max_length=2000)
    concept_img =  models.ImageField(null=True, blank=False)

    def __str__(self):
        return "關於我們"