function clearAllCondition() {
	var x = document.getElementsByTagName('input');
	for(i = 0;i<x.length;i++){
		if(x[i].getAttribute('type')=='checkbox'){
			x[i].checked = false;
		}
		if(x[i].getAttribute('type')=='number'){
			x[i].value = null;
		}
	}
}