//var choice = new Array("korean","japan","taiwan","american")

function select(){
	

	
}