# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Store_list(models.Model):
    name = models.CharField(null=True,max_length=20)
    image = models.ImageField(null=True, blank=False)
    text = models.CharField(null=True,max_length=200)
    hash_tag =  models.CharField(null=True,blank=True,max_length=20)
    second_img = models.ImageField(null=True, blank=True)
    third_img = models.ImageField(null=True, blank=True)
    fourth_img = models.ImageField(null=True, blank=True)
    fifth_img = models.ImageField(null=True, blank=True)
    prefer = models.CharField(null=True,blank = True,max_length=20,default="")
    recommand_meals = models.CharField(null=True,blank = True,max_length=20,default="")
    price =  models.CharField(null=True,blank = True,max_length=20,default="")
    mention =  models.CharField(null=True,blank = True,max_length=20,default="")

    stars=models.FloatField(null=True,max_length=20)
    vegetable = models.BooleanField(default=False)
    Halal=models.BooleanField(default=False)
    is_chinese=models.BooleanField(default=False)
    is_western=models.BooleanField(default=False)
    is_japan=models.BooleanField(default=False)
    is_korean=models.BooleanField(default=False)
    is_expensive=models.BooleanField(default=False)
    location = models.CharField(null=True,max_length=2000)


    def __str__(self):
        return self.name
