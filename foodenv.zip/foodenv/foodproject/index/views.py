from django.shortcuts import render_to_response,render
from django.contrib.auth.models import User
from django.contrib import auth
from django.http import HttpResponseRedirect

def Index(request):
	return render(request,'index.html',locals())


def toSignup(request):
	try:
		userfn = request.GET['firstname']
		userln = request.GET['lastname']
		useremail = request.GET['mail']
		userpass = request.GET['password']
		userpassconfirm = request.GET['repassword']
	except:
		useremail = None
		message = "Error"
	if useremail != None and userpass == userpassconfirm:
		user = User.objects.create_user(str(useremail),useremail,userpass)
		user.last_name = userln
		user.first_name = userfn
		user.save()
	return render(request,'signup.html',locals())


